1

in the files network.html are everything from the network tab like ur router its ip nas nas ip nas2 nas2ip ye you get it u can change them to be ur ip and to what ever name u want 

2

the files usage.json and w.html arent meant to be touched or changed values

3

i.html is also not meant to be changed this is the about the project tab in the side bar do not change the values in there

4

index and oindex has to  be configured by the new user files arent in the same location for every one like for me the files are at /network/nas1/files/htmlwebtest/ for u they are in different location u need to set the correct location for the files 

